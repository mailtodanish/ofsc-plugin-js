// Ready ->init ->initEnd->remove
(() => {
  window.onload = function () {
    console.error("Plugin started...");
    window.OfscPlugin = function () {
      this.getOrigin = (url) => {
        if (url != "") {
          if (url.indexOf("://") > -1) {
            return "https://" + url.split("/")[2];
          } else {
            return "https://" + url.split("/")[0];
          }
        }
        return "";
      };
      this.sendPostMessageData = (data) => {
        console.error(this.getOrigin(document.referrer));
        parent.postMessage(JSON.stringify(data), this.getOrigin(document.referrer));
      };
      this._messageListener = (event) => {
        console.error(event);
        switch (event.data.type) {
          case "init":
            console.log("Init method called");
            this.sendPostMessageData({
              apiVersion: 1,
              method: "initEnd",
            });
            break;
          case "open":
            console.error("Open method called");
            break;
          case "error":
            console.error("Open method called");
            break;
          case "close":
            this.sendPostMessageData({
              apiVersion: 1,
              method: "close",
            });
            break;
        }
      };

      this.init = (messageListener) => {
        window.addEventListener("message", this._messageListener, false);
        console.error("Init method called");

        this.sendPostMessageData({
          apiVersion: 1,
          method: "ready",
          sendInitData: true,
          showHeader: true,
          enableBackButton: true,
        });
      };
    };

    var plugin = new OfscPlugin();
    console.error(plugin);
    plugin.init();
  };
})();
